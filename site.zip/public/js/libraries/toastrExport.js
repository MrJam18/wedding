// @ts-ignore;
export const showAlert = toastr;
//# sourceMappingURL=toastrExport.js.map