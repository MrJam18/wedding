// @ts-ignore;
export const showAlert = toastr;
