var mapProgram;
function setProgramMap(a) {
    $btn = $(this),
        $modal = $("#program-map");
    var e = $modal.find("#program-map-event-id")
        , t = $modal.find("#program-map-reason")
        , o = $("#program-map-wrapper");
    o.show(),
        t.hide(),
    null != mapProgram && mapProgram.destroy();
    var r = [];
    if ("value" == $btn.attr("class"))
        $btn.data("id") && e.val($btn.data("id")),
            r = $btn.data("coords").split(",");
    else if ("form-control" == $btn.attr("class")) {
        var n = $btn.find("option:selected").data("coords");
        n && (r = n.split(","))
    }
    if (r)
        if ((mapProgram = new ymaps.Map("program-map-wrapper",{
            center: 2 == r.length ? r : [37.622093, 55.753994],
            zoom: 16,
            controls: ["zoomControl"]
        })).behaviors.disable("scrollZoom"),
        r.length > 0) {
            var d = "";
            if ("value" == $btn.attr("class"))
                d = "<h4>" + $btn.data("name") + '</h4><p class="date-time">' + $btn.data("date-when") + " в " + $btn.data("time-when") + '</p><p class="addr">' + $btn.data("addr") + "</p>";
            else if ("form-control" == $btn.attr("class")) {
                var s = $btn.find("option:selected");
                d = "<h4>" + s.data("name") + '</h4><p class="date-time">' + s.data("date-when") + " в " + s.data("time-when") + '</p><p class="addr">' + s.data("addr") + "</p>"
            }
            var l = new ymaps.Placemark(r,{
                balloonContentBody: d
            },{
                preset: "twirl#redStretchyIcon",
                draggable: !1
            });
            mapProgram.geoObjects.add(l)
        } else {
            var p = new ymaps.Clusterer({
                preset: "islands#invertedVioletClusterIcons",
                groupByCoordinates: !1,
                clusterDisableClickZoom: !1,
                clusterHideIconOnBalloonOpen: !1,
                geoObjectHideIconOnBalloonOpen: !1,
                hasBalloon: !0
            })
                , m = [];
            e.find("option").each((function(a, e) {
                    var t = $(this)
                        , o = "<h4>" + t.data("name") + '</h4><p class="addr">' + t.data("addr") + "</p>";
                    t.val() && m.push(new ymaps.Placemark(t.data("coords").split(","),{
                        balloonContentBody: o,
                        clusterCaption: t.data("date-when") + " в " + t.data("time-when")
                    },{
                        preset: "islands#violetIcon"
                    }))
                }
            )),
                p.add(m),
                mapProgram.geoObjects.add(p),
                mapProgram.setBounds(p.getBounds(), {
                    checkZoomRange: !0
                })
        }
    else
        o.hide(),
            t.text("Координаты события не обнаружены"),
            t.show()
}
$("#program p.addr span.value, #section-program p.addr span.value").on("click", setProgramMap),
    $("#program-map #program-map-event-id").on("change", setProgramMap);
