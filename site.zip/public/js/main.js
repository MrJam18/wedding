var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { renderTimeTable } from "./src/renderTimeTable.js";
import { HtmlHelper } from "./Classes/Helpers/HtmlHelper.js";
import { createPersonHandler } from "./src/createPersonHandler.js";
import { answerInvitationHandler } from "./src/answerInvitationHandler.js";
import { questionnaireHandler } from "./src/questionnaireHandler.js";
import { initialPersonLogic } from "./src/initialPersonLogic.js";
import { showModal } from "./utils/showModal.js";
import { registrationClickHandler } from "./src/registrationClickHandler.js";
import { showAlert } from "./libraries/toastrExport.js";
renderTimeTable();
let person = null;
initialPersonLogic().then((personValue) => person = personValue);
HtmlHelper.submitEvent('#form-create-person', (ev) => __awaiter(void 0, void 0, void 0, function* () {
    person = yield createPersonHandler(ev);
}));
HtmlHelper.submitEvent('#form-guest-accept', (ev) => __awaiter(void 0, void 0, void 0, function* () {
    yield answerInvitationHandler(ev, person, '#modal-guest-accept');
}));
HtmlHelper.submitEvent('#form-guest-decline', (ev) => __awaiter(void 0, void 0, void 0, function* () {
    yield answerInvitationHandler(ev, person, '#modal-guest-decline');
}));
HtmlHelper.submitEvent('#questionnaire', (ev) => __awaiter(void 0, void 0, void 0, function* () { return yield questionnaireHandler(ev, person); }));
HtmlHelper.addClickEvent('#decline-invite-button', () => {
    if (person)
        showModal('#modal-guest-decline');
    else
        showAlert.error('Сначала пройдите регистрацию из меню');
});
HtmlHelper.addClickEvent('#accept-invite-button', () => {
    if (person)
        showModal('#modal-guest-accept');
    else
        showAlert.error('Сначала пройдите регистрацию из меню');
});
HtmlHelper.addClickEvent('#registration-button', registrationClickHandler);
//# sourceMappingURL=main.js.map