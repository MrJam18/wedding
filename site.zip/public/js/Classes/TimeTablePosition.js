export class TimeTablePosition {
    constructor(address = null, coordinates = null, addressFull = null) {
        this.address = address !== null && address !== void 0 ? address : 'Ленинградская область, Ломоносовский район, территория троицкая гора, д. 33 (Петергоф-Лофт)';
        this.coordinates = coordinates !== null && coordinates !== void 0 ? coordinates : [59.867710, 29.836527];
        this.addressFull = addressFull !== null && addressFull !== void 0 ? addressFull : address;
    }
}
//# sourceMappingURL=TimeTablePosition.js.map