export class Person {
}
//# sourceMappingURL=Person.js.map