export function stopPropagation(ev) {
    ev.stopPropagation();
}
//# sourceMappingURL=stopPropagation.js.map