export function buildFormData(form) {
    const elements = form.elements;
    const data = {};
    for (let i = 0; i < elements.length; i++) {
        const el = elements[i];
        const name = el.name;
        if (name)
            data[name] = el.value;
    }
    return data;
}
//# sourceMappingURL=buildFormData.js.map