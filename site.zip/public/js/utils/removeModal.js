export function removeModal(modalSelector) {
    const modal = document.querySelector(modalSelector);
    const backgrounds = document.querySelectorAll('.modal-backdrop');
    backgrounds.forEach((el) => {
        el.classList.remove('show');
    });
    modal.classList.remove('show');
    modal.style.backgroundColor = 'transparent';
    const body = document.querySelector('body');
    body.classList.remove('modal-open');
    body.style.overflow = 'initial';
    setTimeout(() => {
        modal.style.display = 'none';
        backgrounds.forEach((el) => {
            el.style.display = 'none';
        });
    }, 200);
}
//# sourceMappingURL=removeModal.js.map