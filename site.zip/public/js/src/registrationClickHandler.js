import { showModal } from "../utils/showModal.js";
export function registrationClickHandler(ev) {
    ev.preventDefault();
    showModal('#modal-create-person');
}
//# sourceMappingURL=registrationClickHandler.js.map