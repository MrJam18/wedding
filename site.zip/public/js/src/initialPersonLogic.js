var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { api } from "../services/api.js";
import { Person } from "../Classes/Person.js";
import { HtmlHelper } from "../Classes/Helpers/HtmlHelper.js";
import { showAlert } from "../libraries/toastrExport.js";
export function initialPersonLogic() {
    return __awaiter(this, void 0, void 0, function* () {
        const personId = +localStorage.getItem('personId');
        if (personId) {
            try {
                const { data } = yield api.get('getPersonData/' + personId);
                const person = new Person();
                person.id = data.id;
                person.inviteAnswerId = data.inviteAnswerId;
                person.questionnaireGroupId = data.questionnaireGroupId;
                if (person.inviteAnswerId)
                    HtmlHelper.innerHTML('.accept-note', 'Спасибо, что ответили на приглашение.');
                return person;
            }
            catch (e) {
                console.log(e);
                showAlert.error('Ошибка: ' + e.message);
            }
        }
        return null;
    });
}
//# sourceMappingURL=initialPersonLogic.js.map