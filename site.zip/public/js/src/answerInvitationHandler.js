var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { buildFormData } from "../utils/buildFormData.js";
import { api } from "../services/api.js";
import { showAlert } from "../libraries/toastrExport.js";
import { removeModal } from "../utils/removeModal.js";
import { HtmlHelper } from "../Classes/Helpers/HtmlHelper.js";
let answerId = null;
export function answerInvitationHandler(ev, person, modalSelector) {
    return __awaiter(this, void 0, void 0, function* () {
        ev.preventDefault();
        const form = ev.currentTarget;
        const formData = buildFormData(form);
        formData.personId = person.id;
        if (person.inviteAnswerId)
            formData.answerId = answerId;
        try {
            const { data } = yield api.post('setInvitedAnswer', formData);
            if (!person.inviteAnswerId)
                person.inviteAnswerId = data.answerId;
            removeModal(modalSelector);
            HtmlHelper.innerHTML('.accept-note', 'Спасибо, что ответили на приглашение.');
            showAlert.info('Ваш ответ отправлен молодоженам');
        }
        catch (e) {
            console.log(e);
            showAlert.error('Ошибка: ' + e.message);
        }
    });
}
//# sourceMappingURL=answerInvitationHandler.js.map