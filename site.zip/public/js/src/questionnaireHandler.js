var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { getCheckedData } from "../utils/getCheckedData.js";
import { api } from "../services/api.js";
import { showAlert } from "../libraries/toastrExport.js";
export function questionnaireHandler(ev, person) {
    return __awaiter(this, void 0, void 0, function* () {
        ev.preventDefault();
        if (!person)
            return showAlert.error('Для прохождения опроса зарегистрируйтесь из меню.');
        try {
            const formData = getCheckedData(ev);
            // @ts-ignore
            formData.comment = ev.currentTarget.elements.comment.value;
            formData.personId = person.id;
            if (person.questionnaireGroupId) {
                formData.answer_group_id = person.questionnaireGroupId;
            }
            const { data } = yield api.post('setQuestionnaireAnswers', formData);
            showAlert.info('Данные анкеты успешно сохранены');
            if (!person.questionnaireGroupId) {
                person.questionnaireGroupId = data.answer_group_id;
            }
        }
        catch (e) {
            console.log(e);
            showAlert.error('Ошибка: ' + e.message);
        }
    });
}
//# sourceMappingURL=questionnaireHandler.js.map