export type TimeTablePositionType = {
    address: string
    coordinates: [number, number],
    fullAddress: string
}
