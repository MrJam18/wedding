<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Получен ответ на свадебное приглашение</title>
</head>
<body>
    <?php echo e("$person->surname $person->name $person->patronymic"); ?> сообщил(а) что <?php echo e($inviteAnswer->is_accepted ? '' : 'не '); ?> пойдет на вашу свадьбу.
    <?php if($inviteAnswer->satellites_message): ?>
        <br/>
        Вот, что он(а) сообщил о своих спутниках:
        <br/>
        <?php echo e($inviteAnswer->satellites_message); ?>

    <?php endif; ?>
    <?php if($inviteAnswer->message): ?>
        <br/>
        Он(а) оставил следующее сообщение для вас:
        <br/>
        <?php echo e($inviteAnswer->message); ?>

    <?php endif; ?>
    <br/>
    Данные приглашенного:
    <br/>
    Номер телефона: <?php echo e($person->phone); ?>

    <br/>
    <?php if($person->email): ?>Email: <?php echo e($person->email); ?><?php endif; ?>
</body>
</html>
<?php /**PATH /mnt/22363FAA363F7DBB/projects/wedding-site/resources/views/inviteAnswerEmail.blade.php ENDPATH**/ ?>