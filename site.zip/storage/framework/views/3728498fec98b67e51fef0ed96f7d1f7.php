<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<?php echo e("$person->surname $person->name $person->patronymic"); ?> оставил следующие ответы на свадебную анкету:
<br/>
<?php
$lastQuestionAnswerId = null
?>
<?php $__currentLoopData = $answerGroup->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questionAnswer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($lastQuestionAnswerId === $questionAnswer->question->id): ?>
        , "<?php echo e($questionAnswer->answer->name); ?>"
    <?php else: ?>
        <?php if($lastQuestionAnswerId): ?>.<br/><?php endif; ?>
    На вопрос "<?php echo e($questionAnswer->question->name); ?>" получен ответ "<?php echo e($questionAnswer->answer->name); ?>"
    <?php endif; ?>
    <?php
    $lastQuestionAnswerId = $questionAnswer->question->id
    ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>.
<?php if($answerGroup->comment): ?>
    Также оставлен следующий комментарий: <br/>
    <?php echo e($answerGroup->comment); ?>

<?php endif; ?>
<br/>
Данные приглашенного:
<br/>
Номер телефона: <?php echo e($person->phone); ?>

<br/>
<?php if($person->email): ?>Email: <?php echo e($person->email); ?><?php endif; ?>
</body>
</html>
<?php /**PATH /mnt/22363FAA363F7DBB/projects/wedding-site/resources/views/questionnaireEmail.blade.php ENDPATH**/ ?>